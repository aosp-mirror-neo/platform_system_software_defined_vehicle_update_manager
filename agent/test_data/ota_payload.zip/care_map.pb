

product
2,0,117115ro.product.build.fingerprint"Jgoogle/sdv_core_cf/sdv_core_cf:Baklava/MAIN/eng.briand:userdebug/test-keys
|
system	2,0,48439ro.system.build.fingerprint"Jgoogle/sdv_core_cf/sdv_core_cf:Baklava/MAIN/eng.briand:userdebug/test-keys
�

system_ext	2,0,10009ro.system_ext.build.fingerprint"Jgoogle/sdv_core_cf/sdv_core_cf:Baklava/MAIN/eng.briand:userdebug/test-keys
|
vendor	2,0,14032ro.vendor.build.fingerprint"Jgoogle/sdv_core_cf/sdv_core_cf:Baklava/MAIN/eng.briand:userdebug/test-keys
�
vendor_dlkm2,0,64 ro.vendor_dlkm.build.fingerprint"Jgoogle/sdv_core_cf/sdv_core_cf:Baklava/MAIN/eng.briand:userdebug/test-keys