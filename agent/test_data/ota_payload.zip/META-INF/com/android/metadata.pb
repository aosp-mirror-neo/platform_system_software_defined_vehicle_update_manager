"�
ota-property-files�payload_metadata.bin:4879:28174,payload.bin:4879:243495040,payload_properties.txt:243499977:154,apex_info.pb:1994:2141,care_map.pb:4182:650,metadata:69:673,metadata.pb:810:1136                      "�
ota-streaming-property-files�payload.bin:4879:243495040,payload_properties.txt:243499977:154,apex_info.pb:1994:2141,care_map.pb:4182:650,metadata:69:673,metadata.pb:810:1136                        *
sdv_core_cf2�
sdv_core_cfJgoogle/sdv_core_cf/sdv_core_cf:Baklava/MAIN/eng.briand:userdebug/test-keys
eng.briand ƚ��*362
2025-04-05:n
productsdv_core_cfJgoogle/sdv_core_cf/sdv_core_cf:Baklava/MAIN/eng.briand:userdebug/test-keys"
1741638982:m
systemsdv_core_cfJgoogle/sdv_core_cf/sdv_core_cf:Baklava/MAIN/eng.briand:userdebug/test-keys"
1741638982:q

system_extsdv_core_cfJgoogle/sdv_core_cf/sdv_core_cf:Baklava/MAIN/eng.briand:userdebug/test-keys"
1741638982:m
vendorsdv_core_cfJgoogle/sdv_core_cf/sdv_core_cf:Baklava/MAIN/eng.briand:userdebug/test-keys"
1741638982:r
vendor_dlkmsdv_core_cfJgoogle/sdv_core_cf/sdv_core_cf:Baklava/MAIN/eng.briand:userdebug/test-keys"
1741638982